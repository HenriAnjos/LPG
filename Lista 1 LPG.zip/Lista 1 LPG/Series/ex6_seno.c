#include <stdio.h>

int main() {
    double x, soma = 0.0;
    int n;

    printf("Valor de x (radianos): ");
    scanf("%lf", &x);
    printf("Numero de termos: ");
    scanf("%d", &n);

    double potencia = x;       
    double fatorial = 1.0;     

    for (int i = 0; i < n; i++) {
        if (i == 0) {
            potencia = x;
            fatorial = 1.0;
        } else {
            potencia *= x * x;
            fatorial *= (2.0 * i) * (2.0 * i + 1);
        }

        double sinal = (i % 2 == 0) ? 1.0 : -1.0;
        double termo = sinal * potencia / fatorial;
        soma += termo;
        printf("Termo %d: %+.10f\n", i, termo);
    }

    printf("seno(%.4f) aproximado: %.10f\n", x, soma);
    return 0;
}
